﻿namespace Bots.Instancebuddy2.Dungeons.Classic
{
    public class RazorfenDowns : Dungeon
    {
        #region Overrides of Dungeon

        /// <summary> The mapid of this dungeon. </summary>
        /// <value>The map identifier.</value>
        public override uint MapId
        {
            get { return 129; }
        }

        #endregion
    }
}
