﻿using Bots.Instancebuddy2.Attributes;
using TreeSharp;
using Bots.Instancebuddy2.Helpers;

namespace Bots.Instancebuddy2.Dungeons.Classic
{
    public class RagefireChasm : Dungeon
    {
        #region Overrides of Dungeon

        /// <summary> The mapid of this dungeon. </summary>
        /// <value>The map identifier.</value>
        public override uint MapId
        {
            get { return 389; }
        }

        #endregion

        [EncounterHandler(11517, "Oggleflint")]
        public Composite OggleflintFight()
        {
            return
                new PrioritySelector();
        }

        [EncounterHandler(11520, "Taragaman")]
        public Composite TaragamanFight()
        {
            return
                new PrioritySelector();
        }
    }
}
