﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bots.Instancebuddy2.Dungeons;
using Bots.Instancebuddy2.Helpers;
using Styx;
using Styx.Logic;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

namespace Bots.Instancebuddy2.Dungeons.BurningCrusade
{
    public class SlavePens : Dungeon
    {
        #region Overrides of Dungeon

        /// <summary> The mapid of this dungeon. </summary>
        /// <value>The map identifier.</value>
        public override uint MapId
        {
            get { return 547; }
        }

        /// <summary>Dungeon specific unit target removal.</summary>
        /// <param name="units">The incomingunits.</param>
        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            for (int i = units.Count - 1; i >= 0; i--)
            {
                WoWUnit u = units[i] as WoWUnit;
                if(u == null)
                    continue;
                
                const uint wastewalkerSlave = 17963;
                const uint wastewalkerWorker = 17964;
                const uint coilfangSlavehandler = 17959;
                
                // Remove all "Wastewalker Worker" if there are no, "Coilfang Slavehandler's" around.
                if ((u.Entry == wastewalkerWorker || u.Entry == wastewalkerSlave) && TargetingHelper.GetCountWithin(u.Location, 15f, extra => extra.Entry == coilfangSlavehandler) == 0)
                {
                    units.RemoveAt(i);
                    continue;
                }

                /*
                Information about Wastewalker Worker
                Name = Wastewalker Worker
                Wowhead Id = 17964
                Faction = 190 [Ambient]

                Information about Coilfang Slavehandler
                Name = Coilfang Slavehandler
                Wowhead Id = 17959
                Faction = 74 [Naga]
                 */
            }
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach(WoWObject obj in incomingunits)
            {
                // for the mennu bossfight.
                const uint mennuHealingWard = 20208; 
                const uint taintedStoneskinTotem = 18177;
                const uint mennuTheBetrayer = 17941;

                if ((obj.Entry == mennuHealingWard || obj.Entry == taintedStoneskinTotem) && 
                    TargetingHelper.GetCountWithin(StyxWoW.Me.Location, 40, extra => extra.Entry == mennuTheBetrayer) != 0) {

                    outgoingunits.Add(obj);
                }
            }
        }

        /// <summary>Dungeon specific unit weighting.</summary>
        /// <param name="units">The units.</param>
        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            /*
            Information about Tainted Stoneskin Totem
            Name = Tainted Stoneskin Totem
            Wowhead Id = 18177
            Faction = 74 [Naga]
            
            Information about Mennu's Healing Ward
            Name = Mennu's Healing Ward
            Wowhead Id = 20208
            Faction = 74 [Naga]
            
            #1 Boss
            Information about Mennu the Betrayer
            Name = Mennu the Betrayer
            Wowhead Id = 17941
            Faction = 74 [Naga]
            
            #2 Boss
            Information about Rokmar the Crackler
            Name = Rokmar the Crackler
            Wowhead Id = 17991
            Faction = 16 [Monster]
            */

            for (int i = 0; i < units.Count; i++)
            {
                WoWObject prioObject = units[i].Object;
                const uint mennuHealingWard = 20208;
                const uint taintedStoneskinTotem = 18177;

                if (prioObject.Entry == mennuHealingWard)
                {
                    units[i].Score += 400;
                }

                if(prioObject.Entry == taintedStoneskinTotem)
                {
                    units[i].Score += 100;
                }
            }
        }

        #endregion
    }
}
