﻿using Bots.Instancebuddy2.Dungeons;
using Styx.Logic.Pathing;

namespace Bots.Instancebuddy2.Dungeons.BurningCrusade
{
    public class BloodFurnance : Dungeon
    {
        #region Overrides of Dungeon

        /// <summary> The mapid of this dungeon. </summary>
        /// <value>The map identifier.</value>
        public override uint MapId
        {
            get { return 542; }
        }

        /// <summary> The entrance of this dungeon as a <see cref="WoWPoint"/>. </summary>
        /// <value>The entrance.</value>
        public override WoWPoint Entrance
        {
            get { return new WoWPoint(-311.6548, 3175.894, 27.29512); }
        }

        #endregion
    }
}
