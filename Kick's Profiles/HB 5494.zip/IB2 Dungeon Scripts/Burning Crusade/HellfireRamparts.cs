﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bots.Instancebuddy2.Dungeons;
using Styx.Logic.Pathing;

namespace Bots.Instancebuddy2.Dungeons.BurningCrusade
{
    public class HellfireRamparts : Dungeon
    {
        #region Overrides of Dungeon

        /// <summary> The mapid of this dungeon. </summary>
        /// <value>The map identifier.</value>
        public override uint MapId
        {
            get { return 543; }
        }

        public override WoWPoint Entrance
        {
            get { return new WoWPoint(-365.0169, 3093.254, -14.35639); }
        }

        #endregion
    }
}
