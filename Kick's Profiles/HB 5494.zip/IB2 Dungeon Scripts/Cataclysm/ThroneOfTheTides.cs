﻿using System;
using System.Linq;
using Bots.Instancebuddy2.Attributes;
using Bots.Instancebuddy2.Helpers;
using Styx.WoWInternals;
using TreeSharp;
using Styx;
using Styx.WoWInternals.WoWObjects;
using System.Collections.Generic;
using Action = TreeSharp.Action;

namespace Bots.Instancebuddy2.Dungeons.Cataclysm
{
    public class ThroneOfTheTides : Dungeon
    {
        #region Overrides of Dungeon

        /// <summary> The Map Id of this dungeon. This is the unique id for dungeons thats used to determine which dungeon, 
        /// the script belongs to </summary>
        /// <value>The map identifier.</value>
        public override uint MapId
        {
            get { return 643; }
        }

        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(o =>
                                {
                                    var unit = o as WoWUnit;

                                    if (unit == null)
                                        return false;

                                    // Faceless watcher casting Ground Pound. Melee should stay away
                                    if (unit.CastingSpellId == 76590 && unit.DistanceSqr < 10*10)
                                        return true;

                                    // For Lady Naz'jar encounter. Lady Naz'jar becomes immune while casting Waterspout(40586)
                                    if (unit.CastingSpellId == 40586)
                                        return true;

                                    // For Mindbender encounter. Mindbender becomes immune to magic and heals itself on damage. We should stop dpsing
                                    if (unit.HasAura("Absorb Magic"))
                                        return true;

                                    // For Enurak
                                    if (unit.IsFriendly)
                                        return true;

                                    return false;
                                });
        }

        #endregion

        #region Encounter Handlers

        /// <summary>
        /// Using 0 as BossEntry will make that composite the main logic for the dungeon and it will be called in every tick
        /// You can only have one main logic for a dungeon
        /// The context of the main composite is all units around as List<WoWUnit/>
        /// </summary>
        /// <returns></returns>
        [EncounterHandler(0)]
        public Composite RootLogic()
        {
            return
                new PrioritySelector(
                    ScriptHelpers.CreateTeleporterLogic(51391, 51395),
                    ScriptHelpers.CreateRunAwayFromUnit(40597, 40784, 41201),
                    CreateElevatorLogic()
                    );
        }

        [EncounterHandler(40825, "Erunak Stonespeaker")]
        public Composite ErunakStonespeakerLogic()
        {
            const int earthShardsSpellId = 84931;
            return
                new PrioritySelector(
                    new Decorator(
                        ctx => ((WoWUnit)ctx).CastingSpellId == earthShardsSpellId && ((WoWUnit)ctx).IsTargetingMeOrPet,
                        new Sequence(
                            new Action(ctx => Logger.Write("[Erunak Encounter] Avoiding Earth Shards")),
                            new Action(ctx => WoWMovement.Move(WoWMovement.MovementDirection.StrafeRight, TimeSpan.FromSeconds(2)))))

                    );
        }

        private Composite CreateElevatorLogic()
        {
            return
                new PrioritySelector(
                    new Decorator(
                        ctx =>
                            {
                                var tankInfo =
                                        StyxWoW.Me.PartyMemberInfos.FirstOrDefault(
                                            p => p.HasRole(WoWPartyMember.GroupRole.Tank)) ??
                                        StyxWoW.Me.PartyMemberInfos.OrderBy(p => p.HealthMax).FirstOrDefault();

                                if (tankInfo == null)
                                    return false;

                                var tank = tankInfo.ToPlayer();

                                if (tank == null)
                                    return false;

                                return !StyxWoW.Me.IsOnTransport && tank.IsOnTransport;
                            },
                        new Sequence(
                            new Action(ctx => Logger.Write("[Dungeon General] Jumping for elevator")),
                            new Action(ctx => WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend, TimeSpan.FromMilliseconds(200))))
                    ));
        }

        #endregion
    }
}
