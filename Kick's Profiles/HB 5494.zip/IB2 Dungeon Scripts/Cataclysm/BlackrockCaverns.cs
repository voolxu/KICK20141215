﻿using System;
using System.Linq;
using Bots.Instancebuddy2.Attributes;
using Bots.Instancebuddy2.Helpers;
using CommonBehaviors.Actions;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using TreeSharp;
using Styx;
using Styx.WoWInternals.WoWObjects;
using System.Collections.Generic;
using Action = TreeSharp.Action;

namespace Bots.Instancebuddy2.Dungeons.Cataclysm
{
    public class BlackrockCaverns : Dungeon
    {
        #region Overrides of Dungeon

        /// <summary> The Map Id of this dungeon. This is the unique id for dungeons thats used to determine which dungeon, 
        /// the script belongs to </summary>
        /// <value>The map identifier.</value>
        public override uint MapId
        {
            get { return 645; }
        }

        public override WoWPoint Entrance
        {
            get
            {
                return new WoWPoint(-7570.482f, -1330.446f, 246.5363f);
            }
        }

        /// <summary>
        /// IncludeTargetsFilter is used to add units to the targeting list. If you want to include a mob thats usually removed by the default
        /// filters, you shall use that.
        /// </summary>
        /// <param name="incomingunits">Units passed into the method</param>
        /// <param name="outgoingunits">Units passed to the targeting class</param>
        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (WoWObject obj in incomingunits)
            {
                // For the Rom'ogg boss fight
                if (obj.Entry == ChainsOfWoe)
                {
                    outgoingunits.Add(obj);
                }
            }
        }

        /// <summary>
        /// RemoveTargetsFilter is used to remove units thats not wanted in target list. Like immune mobs etc.
        /// </summary>
        /// <param name="units"></param>
        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(o =>
                                {
                                    var unit = o as WoWUnit;

                                    if (unit == null)
                                        return false;

                                    if (unit.HasAura("Shadow of Obsidius"))
                                        return true;

                                    return false;
                                });
        }

        /// <summary>
        /// WeighTargetsFilter is used to weight units in the targeting list. If you want to give priority to a certain npc, you should
        /// use this method. 
        /// </summary>
        /// <param name="units"></param>
        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var t in units)
            {
                var prioObject = t.Object;

                //We should prio Chains of Woe for Rom'ogg fight
                if (prioObject.Entry == ChainsOfWoe)
                {
                    t.Score += 400;
                }
            }
        }

        #endregion

        #region Encounter Handlers

        const uint ChainsOfWoe = 40447;


        /// <summary>
        /// Using 0 as BossEntry will make that composite the main logic for the dungeon and it will be called in every tick
        /// You can only have one main logic for a dungeon
        /// The context of the main composite is all units around as List<WoWUnit/>
        /// </summary>
        /// <returns></returns>
        [EncounterHandler(0)]
        public Composite RootLogic()
        {
            return
                new PrioritySelector(
                    ScriptHelpers.CreateTeleporterLogic(51340),
                    ScriptHelpers.CreateRunAwayFromAura("Lava Drool")
                    );
        }

        /// <summary>
        /// BossEntry is the Entry of the boss unit. (WoWUnit.Entry)
        /// BossName is optional. Its there just to make it easier to find which boss that composite belongs to.
        /// The context of the encounter composites is the Boss as WoWUnit
        /// </summary>
        /// <returns></returns>
        [EncounterHandler(39665, "Rom'ogg Bonecrusher")]
        public Composite RomoggFightLogic()
        {
            const int theSkullCracker = 75543;
            return
                new PrioritySelector(
                    new Decorator(
                        // If Rom'ogg is casting the skull cracker spell and the party killed the chains of woe, get the hell outta there!
                        ctx => ((WoWUnit)ctx).CastingSpellId == theSkullCracker && !Targeting.Instance.TargetList.Any(u => u.Entry == ChainsOfWoe),
                        new Action(ctx =>
                                       {
                                           Logger.Write("[Rom'ogg Encounter] Moving away from Rom'ogg");

                                           // Get the party member that has the most range from the boss to avoid aoe damage
                                           var player = StyxWoW.Me.PartyMembers.
                                                            OrderByDescending(p => 
                                                                p.Location.DistanceSqr(((WoWUnit)ctx).Location)).
                                                            FirstOrDefault();

                                           return Navigator.GetRunStatusFromMoveResult(Navigator.MoveTo(player.Location));
                                       })
                            ));
        }

        [EncounterHandler(39679, "Corla, Herald of Twilight")]
        public Composite CorlaFightLogic()
        {
            return
                new PrioritySelector();
        }

        #endregion
    }
}
