﻿#region Revision Info

// This file is part of Singular - A community driven Honorbuddy CC
// $Author: bobby53 $
// $Date: 2011-04-13 22:14:06 +0200 (on, 13 apr 2011) $
// $HeadURL: http://svn.apocdev.com/singular/tags/v1/Singular/Extensions.cs $
// $LastChangedBy: bobby53 $
// $LastChangedDate: 2011-04-13 22:14:06 +0200 (on, 13 apr 2011) $
// $LastChangedRevision: 277 $
// $Revision: 277 $

#endregion

using System;
using System.Text;

using Styx.WoWInternals.WoWObjects;
using Styx.Logic;

namespace Singular
{
    internal static class Extensions
    {
        /// <summary>A ulong extension method that converts a WoW performance counter to a DateTime object. </summary>
        /// <remarks>Created 3/26/2011.</remarks>
        /// <param name="performanceCounter">The performanceCounter to act on.</param>
        /// <returns>.</returns>
        public static DateTime PerformanceCounterToDateTime(this ulong performanceCounter)
        {
            return DateTime.Now.Subtract(TimeSpan.FromMilliseconds(Environment.TickCount)).AddMilliseconds(performanceCounter);
        }

        public static bool Between(this double distance, double min, double max)
        {
            return distance >= min && distance <= max;
        }

        /// <summary>
        ///   A string extension method that turns a Camel-case string into a spaced string. (Example: SomeCamelString -> Some Camel String)
        /// </summary>
        /// <remarks>
        ///   Created 2/7/2011.
        /// </remarks>
        /// <param name = "str">The string to act on.</param>
        /// <returns>.</returns>
        public static string CamelToSpaced(this string str)
        {
            var sb = new StringBuilder();
            foreach (char c in str)
            {
                if (char.IsUpper(c))
                {
                    sb.Append(' ');
                }
                sb.Append(c);
            }
            return sb.ToString();
        }

        public static string SafeName(this WoWObject obj)
        {
            if (obj.IsMe)
            {
                return "Myself";
            }

            string name;
            if (obj is WoWPlayer)
            {
                if (RaFHelper.Leader == obj)
                    return "Tank";

                name = ((WoWPlayer)obj).Class.ToString();
            }
            else if (obj is WoWUnit && obj.ToUnit().IsPet)
            {
                name = "Pet";
            }
            else
            {
                name = obj.Name;
            }

            return name;
        }

        public static bool IsPet(this WoWUnit unit)
        {
            return unit.SummonedByUnitGuid != 0 || unit.CharmedByUnitGuid != 0;
        }
    }
}